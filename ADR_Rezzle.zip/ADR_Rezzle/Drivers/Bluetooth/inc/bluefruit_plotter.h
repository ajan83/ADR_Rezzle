#ifndef INC_BLUEFRUIT_PLOTTER_H_
#define INC_BLUEFRUIT_PLOTTER_H_

#include "stm32f4xx_hal.h"



extern void bluefruit_plotter(const char *format, ...);



#endif /* INC_BLUEFRUIT_PLOTTER_H_ */
