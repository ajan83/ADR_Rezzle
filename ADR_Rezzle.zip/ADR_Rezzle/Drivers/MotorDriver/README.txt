E. Fompeyrine 12.10.2021

README.txt

Motortreiber für Projekt ADR

MotorDriverInc -> Inc Ordner.
MotorDriverSrc -> Src Ordner.

includieren:

Motor:
#include "MotorDriverInc/ROXXYBL715s.h"
Servo:
#include "MotorDriverInc/DS725MG.h"
Regler:
#include "MotorDriverInc/MULTIGYROG3.h"

STM-ioc:
Timer/s initialisieren auf gewünschte/n Pin

Main.h:

Handlerinstanzierung:
struct hmotor name;

struct hservo name;

struct hMULTIGYRO name;