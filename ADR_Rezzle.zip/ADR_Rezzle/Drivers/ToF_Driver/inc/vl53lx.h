/*
 * vl53lx.h
 *
 * Authors: Retus Rieben, Maurice Otto, Jan Villiger
 * Date: 16.10.2021
 * Version: V1.0
 * Header File of the vl53lx-Driver
 *
 */

#ifndef TOF_INC_VL53LX_H_
#define TOF_INC_VL53LX_H_

#include "vl53lx_api.h"
#include "53l3a2.h"
#include "main.h"


void VL53LX_Init(VL53LX_Dev_t *dev,VL53LX_MultiRangingData_t *MultiRangingData);
void VL53LX_GetData(VL53LX_Dev_t *dev,VL53LX_MultiRangingData_t *MultiRangingData);
void VL53LX_PrintData(VL53LX_MultiRangingData_t *MultiRangingData);

#endif /* TOF_INC_VL53LX_H_ */
