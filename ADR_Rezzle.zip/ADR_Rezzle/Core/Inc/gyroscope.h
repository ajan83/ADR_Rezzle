/*
 * gyroscope.h
 *
 *  Created on: Oct 11, 2021
 *      Author: annag
 */


#ifndef INC_GYROSCOPE_H_
#define INC_GYROSCOPE_H_

/*------------------------------------------------------------------------
  Includes
/-----------------------------------------------------------------------*/
#include "main.h"
/*------------------------------------------------------------------------
  Defines
/-----------------------------------------------------------------------*/
#define	GYRO_ADDR		    0x6A<<1		// I2C address of gyroscope
#define CTRL2_G				0x11		// control register to select frequency and dps etc.
#define OUTX_L_G			0x22		// output register for X-axis (16-bit), least significant = low-order (D7-D0)
#define OUTX_H_G			0x23		// output register for X-axis (16-bit), most significant = high-order (D15-D8)
#define OUTY_L_G			0x24		// " Y-axis "
#define OUTY_H_G			0x25		// " Y-axis "
#define OUTZ_L_G			0x26		// " Z-axis "
#define OUTZ_H_G			0x27		// " Z-axis "

/*------------------------------------------------------------------------
  Functions
/-----------------------------------------------------------------------*/
//void setDps(uint16_t *maxDps, uint16_t *regMaxDps);
void Gyro_init();
void getAngle(float *x, float *y, float *z);
void Gyro_write(uint8_t address, uint8_t reg, uint8_t data);
void Gyro_read(uint8_t address, uint8_t reg, uint8_t *data, uint8_t bytes);


#endif /* INC_GYROSCOPE_H_ */
